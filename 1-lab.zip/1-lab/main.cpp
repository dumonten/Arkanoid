#include "game_classes.h"

int main()
{
    Arkanoid::Game game;
    game.start();
    return 0;
}